editArea.add_lang("de",{
charmap_but: "Sonderzeichen",
charmap_title: "Sonderzeichen",
charmap_choose_block: "Bereich ausw&auml;hlen",
charmap_insert: "dieses Zeichen einf&uuml;gen"
});
