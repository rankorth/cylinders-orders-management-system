using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace TwoListBoxDragAndDrop
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private int eventCount = 0;
		private int indexOfItemUnderMouseToDrop;
		private int indexOfItemUnderMouseToDrag;
		private Point screenOffset;
		private DateTime eventTime;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.ListBox listBox2;
		private System.Windows.Forms.ListBox listBox3;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			
			
			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.listBox2 = new System.Windows.Forms.ListBox();
			this.listBox3 = new System.Windows.Forms.ListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// listBox1
			// 
			this.listBox1.AllowDrop = true;
			this.listBox1.Items.AddRange(new object[] {
														  "Bearing",
														  "Distance",
														  "Identifier",
														  "Latitude",
														  "Longitude",
														  "Speed"});
			this.listBox1.Location = new System.Drawing.Point(16, 24);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(128, 212);
			this.listBox1.Sorted = true;
			this.listBox1.TabIndex = 0;
			this.listBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox1_MouseDown);
			this.listBox1.QueryContinueDrag += new System.Windows.Forms.QueryContinueDragEventHandler(this.listBox1_QueryContinueDrag);
			this.listBox1.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox1_DragEnter);
			// 
			// listBox2
			// 
			this.listBox2.AllowDrop = true;
			this.listBox2.Location = new System.Drawing.Point(200, 24);
			this.listBox2.Name = "listBox2";
			this.listBox2.Size = new System.Drawing.Size(128, 212);
			this.listBox2.TabIndex = 1;
			this.listBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox2_MouseDown);
			this.listBox2.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox2_DragOver);
			this.listBox2.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox2_DragDrop);
			this.listBox2.QueryContinueDrag += new System.Windows.Forms.QueryContinueDragEventHandler(this.listBox2_QueryContinueDrag);
			this.listBox2.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox2_DragEnter);
			// 
			// listBox3
			// 
			this.listBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.listBox3.BackColor = System.Drawing.SystemColors.Info;
			this.listBox3.Items.AddRange(new object[] {
														  "Info listBox3"});
			this.listBox3.Location = new System.Drawing.Point(16, 256);
			this.listBox3.Name = "listBox3";
			this.listBox3.Size = new System.Drawing.Size(584, 134);
			this.listBox3.TabIndex = 2;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.SystemColors.Info;
			this.label1.Location = new System.Drawing.Point(344, 40);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(224, 56);
			this.label1.TabIndex = 3;
			this.label1.Text = "Info text area";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(344, 224);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(112, 32);
			this.button1.TabIndex = 4;
			this.button1.Text = "Clear info ListBox3 Reset Event Counter";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(328, 104);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(112, 32);
			this.button2.TabIndex = 5;
			this.button2.Text = "Clear Right ListBox (listBox2)";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(624, 406);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.listBox3);
			this.Controls.Add(this.listBox2);
			this.Controls.Add(this.listBox1);
			this.Name = "Form1";
			this.Text = "Two ListBox DragDrop Demo";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void listBox1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			// starts a DoDragDrop operation with allowed effect  "Copy"
			eventCount = eventCount + 1;  // increment event counter
			DateTime date = DateTime.Now; // get time of event
			listBox3.Items.Add( eventCount.ToString() + ".0  listBox1_MouseDown event  \"Fired\"  on " + date.ToString("dddd")+ " at " + date.ToString("HH:mm:ss.ffffff"));
			int indexOfItem = listBox1.IndexFromPoint(e.X, e.Y); 
			if(indexOfItem >= 0 && indexOfItem < listBox1.Items.Count)  // check that an string is selected
			{
				// show the selection made in the bottom listBox3
				listBox3.Items.Add( "   " + eventCount.ToString() + ".1 ListBox1 Item Selected at MouseDown  was \"" + listBox1.Items[indexOfItem]+"\"" );
				listBox3.Items.Add( "   " + eventCount.ToString() + ".2 DoDragDrop operation started from listBox1_MouseDown event! ");
				listBox3.Items.Add( "   " + eventCount.ToString() + ".2.1   DoDragDrop method's \"object data\" parameter is: "+(listBox1.Items[indexOfItem]).ToString() + " whose type is: " + listBox1.Items[indexOfItem].GetType());
				listBox3.Items.Add( "   " + eventCount.ToString() + ".2.1   DoDragDrop method's   DragDropEffects parameter is set to: " + DragDropEffects.Copy.ToString());

				// Set allowed DragDropEffect to Copy selected from DragDropEffects enumberation of None, Move, All etc.
				listBox1.DoDragDrop(listBox1.Items[indexOfItem], DragDropEffects.Copy );
			}
			
			
		}

		private void listBox1_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
		{
			// This event will  never be triggered unless listBox1.AllowDrop == true
			// Adding this event to listBox1's events allows the cursor to change
			// to indicate to the user that a copy dragdrop operation is underway.
			// Execution here signifies a DragDrop operation is running on this control
			// In this demo, I really don't want to allow a drop into listBox1.
			// Since I haven't written a listBox1_DragDrop event handler
			// an insertion into listBox1's Items never occurs.  
			eventTime = DateTime.Now;
			e.Effect = DragDropEffects.Copy;  // The cursor changes to show Copy
			GiveInfoAboutDragDropEvent(eventTime, "listBox1_DragEnter", sender,  e );
		
		}

		private void listBox1_QueryContinueDrag(object sender, System.Windows.Forms.QueryContinueDragEventArgs e)
		{
		
			// This event is fired when there is a change in the keyboard or mouse button state
			// during a drag-and-drop operation.  This means that if the cursor is
			// moved,  this event is fired.  If the keyboard is pressed or if a 
			// change to a mouse button occurs(press or release), this even is fired. 
			// In other words, this event is fired alot!
			// For the purposes of the demo, if the mouse cursor  moves off Form1's boundaries
			// during DoDragDrop operation initiated by the  listBox2 mousedown event
			// the DoDragDrop operation initiated should be cancelled.

			// ( from VS. .NET Combined Collection Control.DoDragDrop documentation)
			// The screenOffset is used to account for any desktop bands 
			// that may be at the top or left side of the screen when 
			// determining when to cancel the drag drop operation.
			screenOffset = SystemInformation.WorkingArea.Location;

			ListBox lb = sender as ListBox;

			if (lb != null) 
			{
				Form f = lb.FindForm();
				// Cancel the drag if the mouse moves off the form. The screenOffset
				// takes into account any desktop bands that may be at the top or left
				// side of the screen.
				if (((Control.MousePosition.X - screenOffset.X) < f.DesktopBounds.Left) ||
					((Control.MousePosition.X - screenOffset.X) > f.DesktopBounds.Right) ||
					((Control.MousePosition.Y - screenOffset.Y) < f.DesktopBounds.Top) ||
					((Control.MousePosition.Y - screenOffset.Y) > f.DesktopBounds.Bottom)) 
				{
					e.Action = DragAction.Cancel;
				}
			}

			eventCount = eventCount + 1;  // increment event counter
			DateTime date = DateTime.Now; // get time of event
			listBox3.Items.Add( eventCount.ToString() + ".0  listBox1_QueryContinueDrag event  \"Fired\"  on " + date.ToString("dddd")+ " at " + date.ToString("HH:mm:ss.ffffff"));
			listBox3.Items.Add("    " + eventCount.ToString()+ ".1 DragAction set to " + e.Action.ToString());
		}

		private void listBox2_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			eventCount = eventCount + 1;
			int indexOfItem = listBox2.IndexFromPoint(e.X, e.Y);
			DateTime date = DateTime.Now;
			listBox3.Items.Add( eventCount.ToString() + ".0  listBox2_MouseDown event  \"Fired\"  on " + date.ToString("dddd")+ " at " + date.ToString("HH:mm:ss.ffffff"));
			if(indexOfItem >= 0 && indexOfItem < listBox2.Items.Count)  // check we clicked down on a string
			{
				listBox3.Items.Add("   " + eventCount.ToString() + ".1  ListBox2 Item Selected at MouseDown = " + listBox2.Items[indexOfItem] );
				// Set allowed DragDropEffect to Move selected from DragDropEffects enumberation of None, Move, All etc.
				// A mouse down in listBox2 in this demo implies either delete or rearrange
				// is started, therefore the allowed DragDropEffect is always Move.
				listBox2.DoDragDrop(listBox2.Items[indexOfItem], DragDropEffects.Move );
				listBox3.Items.Add( "   " + eventCount.ToString() + ".2 DoDragDrop operation started from listBox2_MouseDown event! ");
				listBox3.Items.Add( "   " + eventCount.ToString() + ".2.1   DoDragDrop method's \"object data\" parameter is: "+(listBox2.Items[indexOfItem]).ToString() + "  whose type is: " + listBox2.Items[indexOfItem].GetType());
				listBox3.Items.Add( "   " + eventCount.ToString() + ".2.1   DoDragDrop medhod's DragDropEffects parameter is set to: " + DragDropEffects.Copy.ToString());
			}
		}

		private void listBox2_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
		{  
			// fill the informational listBox3
			eventTime = DateTime.Now;
			GiveInfoAboutDragDropEvent(eventTime, "listBox2_DragEnter", sender,  e );

			// change the drag cursor to show that listbox2 is ready and set to accept data entry
			// either to Copy or Move
			// make sure we aren't inadvertently passing one of the other objects allow such as a bitmap!
		  
			if (e.Data.GetDataPresent(DataFormats.StringFormat) && (e.AllowedEffect == DragDropEffects.Copy)	) 
				e.Effect = DragDropEffects.Copy;
			else
				e.Effect = DragDropEffects.Move;
			
			// since we may have changed the cursor,  show current cursor shape
			listBox3.Items.Add("  " + eventCount.ToString() +   ".4.1  after event execution  e.Effect is now " + e.Effect.ToString());

		}

		private void listBox2_QueryContinueDrag(object sender, System.Windows.Forms.QueryContinueDragEventArgs e)
		{
		
			// This event is fired when there is a change in the keyboard or mouse button state
			// during a drag-and-drop operation.  This means that if the cursor is
			// moved,  this event is fired.  If the keyboard is pressed or if a 
			// change to a mouse button occurs(press or release), this even is fired. 
			// In other words,  this event is fired alot!
			// For the purposes of the demo, if the mouse cursor  moves off Form1's boundaries
			// during DoDragDrop operation initiated by the  listBox2 mousedown event
			// the DoDragDrop operation initiated should be cancelled.

			// ( from VS. .NET Combined Collection Control.DoDragDrop documentation)
			// The screenOffset is used to account for any desktop bands 
			// that may be at the top or left side of the screen when 
			// determining when to cancel the drag drop operation.
			screenOffset = SystemInformation.WorkingArea.Location;

			ListBox lb = sender as ListBox;

			if (lb != null) 
			{
				Form f = lb.FindForm();
				// Cancel the drag if the mouse moves off the form. The screenOffset
				// takes into account any desktop bands that may be at the top or left
				// side of the screen.
				if (((Control.MousePosition.X - screenOffset.X) < f.DesktopBounds.Left) ||
					((Control.MousePosition.X - screenOffset.X) > f.DesktopBounds.Right) ||
					((Control.MousePosition.Y - screenOffset.Y) < f.DesktopBounds.Top) ||
					((Control.MousePosition.Y - screenOffset.Y) > f.DesktopBounds.Bottom)) 
				{
					e.Action = DragAction.Cancel;
				}
			}

			eventCount = eventCount + 1;  // increment event counter
			DateTime date = DateTime.Now; // get time of event
			listBox3.Items.Add( eventCount.ToString() + ".0  listBox2_QueryContinueDrag event  \"Fired\"  on " + date.ToString("dddd")+ " at " + date.ToString("HH:mm:ss.ffffff"));
			listBox3.Items.Add("    " + eventCount.ToString()+ ".1 DragAction set to " + e.Action.ToString());
		}


		private void listBox2_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
		{
			if(e.Data.GetDataPresent(DataFormats.StringFormat)) 
			{
				if(indexOfItemUnderMouseToDrop >= 0 && indexOfItemUnderMouseToDrop < listBox2.Items.Count)
				{
					listBox2.Items.Insert(indexOfItemUnderMouseToDrop,e.Data.GetData(DataFormats.Text));
				}
				else
				{
					// add the selected string to bottom of list
					listBox2.Items.Add(e.Data.GetData(DataFormats.Text));
				}


			}
			// fill info listBox
			eventTime = DateTime.Now;
			GiveInfoAboutDragDropEvent(eventTime, "listBox2_DragDrop", sender,  e );
			DateTime date = DateTime.Now;

			label1.Text = "";  // Erase info label.
		
		}

		private void listBox2_DragOver(object sender, System.Windows.Forms.DragEventArgs e)
		{
			
			indexOfItemUnderMouseToDrop = 
				listBox2.IndexFromPoint(listBox2.PointToClient(new Point(e.X, e.Y)));

			if (indexOfItemUnderMouseToDrop != ListBox.NoMatches)
			{   
				// if the computed index is not within listBox2, then put it at the end (bottom)
				label1.Text = "\'"+e.Data.GetData(DataFormats.Text)+"\'"+ " will be placed  before item #" + (indexOfItemUnderMouseToDrop + 1)+
							     "\n which is "+ listBox2.SelectedItem;
				// pass the location back to use in the dragDrop event method.
				listBox2.SelectedIndex = indexOfItemUnderMouseToDrop;

			} 
			else
			{
				// prompt the user where the drop will occur
				label1.Text = "\'"+e.Data.GetData(DataFormats.Text)+ "\'"+ " will be added to the bottom of the listBox." ; 
				// save the intended drop location as an index number into the listBox2 Item collection.
				listBox2.SelectedIndex = indexOfItemUnderMouseToDrop;
			}

			// if  the MouseDown event set the DragDrop operation to be a move event
			// immediately delete the item.  This has the desirable effect of
			// deleting any duplicate strings that might have been moved into
			// listBox2
			if(e.Effect == DragDropEffects.Move)  // When moving an item within listBox2
				listBox2.Items.Remove((string)e.Data.GetData(DataFormats.Text));

			// fill the informational listBox3
			eventTime = DateTime.Now;
			GiveInfoAboutDragDropEvent(eventTime, "listBox2_DragOver", sender,  e );
		}

		

		private void button1_Click(object sender, System.EventArgs e)  // clear and reset listBox3 and info label
		{
			listBox3.Items.Clear();
			eventCount = 0;
			label1.Text = "";
		}

		private void button2_Click(object sender, System.EventArgs e) // clear right hand listBox2
		{
			listBox2.Items.Clear();
		}

		private void GiveInfoAboutDragDropEvent(DateTime eventTime, string dragDropEventName, object originalSender, System.Windows.Forms.DragEventArgs e )
		{
			eventCount = eventCount + 1; 
			listBox3.Items.Add( eventCount.ToString() + ".0 " + dragDropEventName + "  event was  \"Fired\"  on " + eventTime.ToString("dddd")+ " at " + eventTime.ToString("HH:mm:ss.ffffff"));
			listBox3.Items.Add("  " + eventCount.ToString() +   ".1  sender is" + originalSender.ToString());
			listBox3.Items.Add("  " + eventCount.ToString() +   ".2  e.Data.GetData reports  IDataObject contains: " + e.Data.GetData(DataFormats.Text));
			listBox3.Items.Add("  " + eventCount.ToString() +   ".3  e.AllowedEffect is " + e.AllowedEffect.ToString());
			listBox3.Items.Add("  " + eventCount.ToString() +   ".4  e.Effect upon event entry is " + e.Effect.ToString());
			//listBox3.SetSelected(listBox3.Items.Count, true);
		}

		private void Form1_DragOver(object sender, System.Windows.Forms.DragEventArgs e)
		{
			// Each time the cursor is moved outside of the SystemInformation.DragSize 
			// this event is fired.  This will rapidly fill up your informational listBox3 so 
			// leave it commented out.   On my system,  the DragSize is a rectangle 4 pixels
			// by 4 pixels. So everytime you move left or right by 4 pixesl or up or down by four
			// pixels with your left button depressed and held , 
			// Form1_DragOver will be fired.   You can determine the rectangle 
			// dimensions on your pc by putting a break at the following statement
			// then examining "dragSize" with a quickWatch window.

			Size dragSize = SystemInformation.DragSize;

			// Optionally fill informational listBox3
			//	eventTime = DateTime.Now;
			//	GiveInfoAboutDragDropEvent(eventTime, "Form1_DragOver", sender,  e );
		}

		private void Form1_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
		{
		//			// commented out because of the mess it creates.  Put it back in to investigate
		//			// the events triggered by moving between listBoxes and over Form1
		//			eventTime = DateTime.Now;
		//			GiveInfoAboutDragDropEvent(eventTime, "Form1_DragEnter", sender,  e );
		//
		//
		}









	
	}
}
